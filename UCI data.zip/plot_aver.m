clc,clear
data1 = xlsread('results.xlsx','R53:AL53');  %--
data2 = xlsread('results.xlsx','R72:AL72');  %+-
data3 = xlsread('results.xlsx','R91:AL91');  %-+
data4 = xlsread('results.xlsx','R110:AL110');  %++
S = -5:0.5:5;
plot(S,data1,'.-');
hold on
plot(S,data2,'.-');
hold on
plot(S,data3,'.-');
hold on
plot(S,data4,'.-');
xlabel('LogS');
ylabel('Average Rank Value');