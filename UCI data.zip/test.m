clc,clear
RR = [3.05 3.05 2.05 1.85];
RR_2 = RR.^2;
S_RR_2 = sum(RR_2);
N = 10;
k = 4;
Chi_RR = (S_RR_2-25)*12*N/(k*(k+1));
F_RR = (N-1)*Chi_RR/(N*(k-1)-Chi_RR);