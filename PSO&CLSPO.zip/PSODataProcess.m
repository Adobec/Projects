clc,clear all,close all
load('test1_PSO_02232130')
mean25_5 = [];
for i = 1:5
    for j = 1:25
        sum = 0;
        for k = 1:10
            count = (j-1)*10+k;
            sum = sum + CLPSO_new_gbestval_res(count,i);
        end
        mean25_5(j,i) = sum/10;
    end
end
meanRank = [];
for i = 1:5
    [~,A] = sort(mean25_5(:,i));
    meanRank(:,i) = zeros(size(A));
    meanRank(A,i) = (1:length(A))';
end
meanRankmean = mean(meanRank')';
[~,A] = sort(meanRankmean);
B = zeros(size(A));
B(A) = (1:length(A))';