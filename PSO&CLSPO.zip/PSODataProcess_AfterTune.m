clc,clear all,close all
load('CLPSO_AfterTune_02251810')
Data = CLPSO_new_gbestval_res';
M = mean(Data);
S = std(Data);
