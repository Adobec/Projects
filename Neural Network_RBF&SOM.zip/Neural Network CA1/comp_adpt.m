function Wcen = comp_adpt(Wcen,X,node_num,yita,sigma,flag,distance_Bet_nodes)
    for i = 1:node_num
        distance_X_nodes(i) = norm(Wcen(i,:)-X);    %第i个node到X的距离记在dXn的第i个位置上
    end
    [~,idx] = min(distance_X_nodes);    %故第idx个node离X最近
    if flag == 1
        for i = 1:16
            Wcen(i,:) = Wcen(i,:) + yita*exp(-((distance_Bet_nodes(i,idx))^2)/(2*(sigma^2)))*(X-Wcen(i,:));
        end
    else
            Wcen(idx,:) = Wcen(idx,:) + yita*(X-Wcen(idx,:));
    end
end