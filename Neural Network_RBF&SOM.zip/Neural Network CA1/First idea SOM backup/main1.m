clc,clear all,close all;
D = load('data_train.mat');
X = D.data_train;
[N,M] = size(X);
%% Initializing the weight matrix
W = rand(33,16)/1000;
node_num = size(W,2);
for i = 1:node_num
    Wnor(:,i) = W(:,i)/max(W(:,i));
end
Wnor = Wnor';
%% Self-organizing phase
sigma0 = 2.121;
n = 1:1000;
yita = 0.1*exp(-n/1000);
tao1 = 1000/log(sigma0);
sigma = sigma0*exp(-n/tao1);
for i = 1:1000
    for j = 1:N
        Wnor = comp_adpt(Wnor,X(j,:),node_num,yita(i),sigma(i),1);
    end
end
%% Convergence phase
yita = 0.01;
sigma = nan;
for i = 1:500*node_num
    for j = 1:N
        Wnor = comp_adpt(Wnor,X(j,:),node_num,yita,sigma,0);
    end
end
%% φ matrix
sigma_G = 0.1;
for i = 1:N
    for j = 1:node_num
        d = norm(X(i,:)-Wnor(j,:));
        O(i,j) = exp(-(d^2)/(2*sigma_G^2));
    end
end