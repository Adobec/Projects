function Wnor = comp_adpt(Wnor,X,node_num,yita,sigma,flag)
    P = [0 0;1 0; 2 0;3 0;0 1;1 1;2 1;3 1;0 2;1 2;2 2;3 2;0 3;1 3;2 3;3 3];
    for i = 1:16
        for j = 1:16
            distance_Bet_nodes(i,j) = norm(P(i,:)-P(j,:));
        end
    end
    for i = 1:node_num
        distance_X_nodes(i) = norm(Wnor(i,:)-X);    %第i个node到X的距离记在dXn的第i个位置上
    end
    [~,idx] = min(distance_X_nodes);    %故第idx个node离X最近
    if flag == 1
        for i = 1:16
            Wnor(i,:) = Wnor(i,:) + yita*exp(-((distance_Bet_nodes(i,idx))^2)/(2*(sigma^2)))*(X-Wnor(i,:));
        end
    else
            Wnor(idx,:) = Wnor(idx,:) + yita*(X-Wnor(idx,:));
    end
end