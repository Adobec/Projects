clc,clear all,close all;
X = load('data_train.mat').data_train;
label_train = load('label_train.mat').label_train;
data_test = load('data_test.mat').data_test;
[N,M] = size(X);
P = [0 0;1 0; 2 0;3 0;0 1;1 1;2 1;3 1;0 2;1 2;2 2;3 2;0 3;1 3;2 3;3 3];
for i = 1:16
    for j = 1:16
        distance_Bet_nodes(i,j) = norm(P(i,:)-P(j,:));
    end
end
%% Initializing the weight matrix
node_num = 16;
for i = 1:33
   Wcen(:,i) = (randperm(1000,node_num)/10000000)';
end
%% Self-organizing phase
sigma0 = 2.121;
n = 1:1000;
yita = 0.1*exp(-n/1000);
tao1 = 1000/log(sigma0);
sigma = sigma0*exp(-n/tao1);
for i = 1:1000
    j = randperm(N,1);
    Wcen = comp_adpt(Wcen,X(j,:),node_num,yita(i),sigma(i),1,distance_Bet_nodes);
end
%% Convergence phase
yita = 0.01;
sigma = nan;
for i = 1:500*node_num
    j = randperm(N,1);
    Wcen = comp_adpt(Wcen,X(j,:),node_num,yita,sigma,0,distance_Bet_nodes);
end
%% φ matrix Oj(i)
% dall = pdist(Wcen);
% dmax = max(dall);
sigma_G = sqrt(node_num/2);
for i = 1:N
   for j = 1:node_num
       d = norm(X(i,:)-Wcen(j,:));%dist(X(i,:),Wcen(j,:)');
       O(i,j) = exp(-(d^2)/(2*sigma_G^2));
   end
end
O(:,j+1) = ones(N,1);
%% Least Squared Method
WH_O_LSM = ((O'*O)^(-1))*O'*label_train;
%% Test
out = zeros(N,1);
for i = 1:N
    for j = 1:node_num
        d_test = norm(X(i,:)-Wcen(j,:));
        out(i,:) = out(i,:) + WH_O_LSM(j,:)*exp(-(d_test.^2)/(2*sigma_G^2));
    end
    out(i,:) = out(i,:) + WH_O_LSM(end);
end
for i = 1:N
    if out(i) >= 0
        out(i) = 1;
    else
        out(i) = -1;
    end
end
test = label_train' - out';
xx = 1:330;
plot(xx,test,'o')
accuracy = 1-sum(sum(test~=0))/330
%% SVM
% Z = fitcsvm(O(:,1:16),label_train);
% w = Z.Beta;
% b = Z.Bias;
% WH_O_LSM = [w;b];
%% Predicting
Nt = size(data_test,1);
label_test = zeros(Nt,1);
for i = 1:Nt 
    for j = 1:node_num
        d_Ltest = norm(data_test(i,:)-Wcen(j,:));
        label_test(i,:) = label_test(i,:) + WH_O_LSM(j,:)*exp(-(d_Ltest.^2)/(2*sigma_G^2));
    end
    label_test(i,:) = label_test(i,:) + WH_O_LSM(end);
end
for i = 1:Nt
    if label_test(i) > 0
        label_test(i) = 1;
    else
        label_test(i) = -1;
    end
end
temp = 1:21;
figure
plot(temp,label_test')
hold on
plot(temp,label_test','*')